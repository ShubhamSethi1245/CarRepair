package com.carRepair.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carRepair.Entity.Car;
import com.carRepair.Entity.Repair;
import com.carRepair.Repo.CarRepo;
import com.carRepair.Repo.RepairRepo;

import jakarta.transaction.Transactional;

@Service
public class CarService {

	@Autowired
	private CarRepo carRepo;

	@Autowired
	private RepairRepo repairRepo;

	/**
	 * This Method for Save Car & Its Repair
	 * 
	 * @return
	 */
	@Transactional
	public Car saveCar(Car car) {
		return carRepo.save(car);
	}

	/**
	 * This Method for Save Cars & Its Repair
	 * 
	 * @return
	 */
	@Transactional
	public Repair saveRepair(Repair repair) {
		Car car = repair.getCar();
		if (car != null && car.getId() == 0) {
			car = carRepo.save(car);
			repair.setCar(car);
		}
		return repairRepo.save(repair);
	}

	/**
	 * This Method for get Particular Car & Its Repair with Id
	 * 
	 * @return
	 */
	public Car getCar(int id) {

		if (!carRepo.findById(id).isEmpty()) {
			return carRepo.findById(id).get();
		} else {
			return null;
		}

	}

	/**
	 * This Method for get All Cars & Its Repairs
	 * 
	 * @return
	 */
	public List<Car> getAllCar() {
		return carRepo.findAll();
	}

	/**
	 * This Method for Delete Car & Its Repair with Id
	 * 
	 * @return
	 */
	public String deleteCar(int id) {
		if (getCar(id) != null && getCar(id).getRepair() != null) {
			repairRepo.deleteById(getCar(id).getRepair().getId());
			carRepo.deleteById(id);
			return "delete Successfully";
		} else {
			return "No Record";
		}

	}
}
