package com.carRepair.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.carRepair.Entity.Repair;

public interface RepairRepo  extends JpaRepository<Repair, Integer>{

}
