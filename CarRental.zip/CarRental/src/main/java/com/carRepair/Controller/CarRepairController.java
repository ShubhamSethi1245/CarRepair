package com.carRepair.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.carRepair.Entity.Car;
import com.carRepair.Entity.Repair;
import com.carRepair.Service.CarService;

@RestController
@RequestMapping("/api/car")
public class CarRepairController {

	@Autowired
	private CarService carService;

	/**
	 * This Api for Create Car & its Repair
	 * @param car
	 * @return
	 */
	@PostMapping("/create")
	public ResponseEntity<?> createCar(@RequestBody Car car) {
		try {
			Car savedCar = carService.saveCar(car);
			return ResponseEntity.ok(savedCar);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}

	}
	
	/**
	 * This Api for update Car & its Repair
	 * @param car
	 * @return
	 */
	@PutMapping("/update")
	public ResponseEntity<?> updateCar(@RequestBody Car car) {
		try {
			Car savedCar = carService.saveCar(car);
			return ResponseEntity.ok(savedCar);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}

	}

	/**
	 * This Api for Create Repair
	 * @param repair
	 * @return
	 */
	@PostMapping("/createRepair")
	public ResponseEntity<?> createRepair(@RequestBody Repair repair) {
		try {
			Repair savedRepair = carService.saveRepair(repair);
			return ResponseEntity.ok(savedRepair);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * This Api is get Particular Car With Id And Its Repair as well
	 * @param id
	 * @return
	 */
	@GetMapping("/{id}")
	public ResponseEntity<?> getCar(@PathVariable int id) {
		try {
			Car car = carService.getCar(id);
			if (car != null) {
				return new ResponseEntity<Car>(car, HttpStatus.OK);
			} else {
				return new ResponseEntity<>("Not Found", HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}

	}

	/**
	 * This Api for Get All Car & Its Repair
	 * @return
	 */
	@GetMapping
	public ResponseEntity<?> getAllCar() {
		try {
			if (carService.getAllCar().isEmpty()) {
				return new ResponseEntity<>("No Record Found", HttpStatus.OK);
			} else {
				return new ResponseEntity<List<Car>>(carService.getAllCar(), HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}

	}

	/**
	 * this Api for for Delete Car & Its Repair
	 * @param id
	 * @return
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteCar(@PathVariable int id) {
		try {
			return new ResponseEntity<>(carService.deleteCar(id), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

}
