package com.carRepair.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.carRepair.Entity.Car;

public interface CarRepo extends JpaRepository<Car, Integer> {

}
